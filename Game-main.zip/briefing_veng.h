//Kirill Vengerov 9"V"

class brief
{
public:
    void introduction();
};

void brief::introduction()
{
        txSelectFont ("Usually-font", 40);
        txSetFillColor(RGB(0,0,0));
        txClear();
        txTextOut(48,144,"Hello user! If you have");
        txTextOut(48,192,"read the briefing, press Enter");
        txRectangle (192,288, 240, 336);
        txRectangle (192,336, 240, 384);
        txRectangle (144,336, 192, 384);
        txRectangle (240,336, 288, 384);
        txDrawText  (192,288, 240, 336, "W");
        txDrawText  (192,336, 240, 384, "S");
        txDrawText  (144,336, 192, 384, "A");
        txDrawText  (240,336, 288, 384, "D");
        txSleep(1000);
}
